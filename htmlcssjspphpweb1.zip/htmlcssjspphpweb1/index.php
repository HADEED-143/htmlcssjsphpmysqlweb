//<?php 
//	include("includes/config.php");
//?>


<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="jsp/index.js">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.0/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/index.css">

	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/js/all.min.js">

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PHP Website DENTIST</title>
</head>
<body>
	<header class="header fixed-top">
		
		<div class="container">

			<div class="row align-items-center justify-content between">

			<a href="#home" class="logo">Dental<span>Care</span></a>	
			<nav class="nav">
				<a href="#home">home</a>
				<a href="#about">about</a>
				<a href="#services">services</a>
				<a href="#services">services</a>
				<a href="#contact">contact</a>

			</nav>
				<a href="#contact" class="link-btn">Make appointment</a>

				<div id="menu-btn" class="fas fa-bars"></div>
			</div>
		</div>
	</header>

	<section class="home" id="home">
		<div class="container">
			<div class="row min-vh-100 align-items-center">
				<div class="content text-center text-md-left">
				<h3>Let us develop web</h3>
				<p>Let us develop webLet us develop webLet us develop webLet us develop webLet us develop webLet us develop webLet us develop webLet us develop webLet us develop webLet us develop web</p>
				<a href="#contact" class="link-btn">Make appoitment</a>
				
			</div>
		</div>
		</div>
	</section>

	<section class="about" id="about">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-6 image">
					<img src="graphics/aboutimg1.jpg">
				</div>
				<div class="col-md-6 content">
					<span>
						About us
					</span>
					<h3>True health care</h3>
					<p>True health careTrue health careTrue health careTrue health careTrue health careTrue health careTrue health care</p>

				</div>

			</div>

		</div>
	</section>

	<section class="services" id="services">
		<h1 class="heading">Our heading</h1>
		<div class="box-container container">
			<div class="box">
				<img src="graphics/servicesimg1.jpg" alt="Services image">
				<h3>Alingment Specialist</h3>
				<p>Alingment SpecialistAlingment SpecialistAlingment SpecialistAlingment SpecialistAlingment Specialist</p>
			</div>

				<div class="box">
				<img src="graphics/servicesimg2.jpg" alt="Services image">
				<h3>Teeth Specialist</h3>
				<p>Alingment SpecialistAlingment SpecialistAlingment SpecialistAlingment SpecialistAlingment Specialist</p>
			</div>

				<div class="box">
				<img src="graphics/servicesimg3.jpg" alt="Services image">
				<h3>Root canal Specialist</h3>
				<p>Alingment SpecialistAlingment SpecialistAlingment SpecialistAlingment SpecialistAlingment Specialist</p>
			</div>

		</div>

	</section>


	<section class="process">
		<h1 class="heading">work processes</h1>

		<div class="box-container container">
			<div class="box">
				<img src="graphics/processimg1.jpg" alt="processimage">
				<h3>Cosmetic dentistry </h3>
				<p>Lorem10</p>

			</div>
			<div class="box">
				<img src="graphics/processimg2.jpg" alt="processimage">
				<h3>Cosmetic dentistry </h3>
				<p>Lorem10</p>

			</div>
			<div class="box">
				<img src="graphics/processimg3.jpg" alt="processimage">
				<h3>Cosmetic dentistry </h3>
				<p>Lorem10</p>

			</div>



		</div>
		

	</section>


	<section class="reviews" id="reviews">
		<h1 class="heading">Satisfied clients</h1>
		
		<div class="box-container container">
			<div class="box">
				<img src="graphics/reviewpic1.jpg" alt="pics1">
				<p>lorem ipsum101301030230234004023040304loremloremloremlorenmlornmelonrmelonrelonmerlonmerlorne</p>
				<div class="stars">
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star-half-alt"></i>
				</div>	
				<h3>jOHN LOREM</h3>
				<span>Satisified client</span>	
			</div>

				<div class="box">
				<img src="graphics/reviewpic2.jpg" alt="pics1">
				<p>lorem ipsum101301030230234004023040304loremloremloremlorenmlornmelonrmelonrelonmerlonmerlorne</p>
				<div class="stars">
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star-half-alt"></i>
				</div>	
				<h3>jOHN LOREM</h3>
				<span>Satisified client</span>	
			</div>

				<div class="box">
				<img src="graphics/reviewpic3.webp" alt="pics1">
				<p>lorem ipsum101301030230234004023040304loremloremloremlorenmlornmelonrmelonrelonmerlonmerlorne</p>
				<div class="stars">
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star"></i>
				<i class="fas fa-star-half-alt"></i>
				</div>	
				<h3>jOHN LOREM</h3>
				<span>Satisified client</span>	
			</div>
		</div>	

	</section>


	<section class="contact" id="contact">
		<h1 class="heading">Make appointment</h1>
		

		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
			<?php
		if (isset($message)) {
			foreach ($message as $message) {
				// code...
			}
		 	echo'<p class="message">'.$message.'</p>';
		 } 

		?>
		<p class="message"> testing message</p>
			<span>Name</span>
			<input type="text" name="name" placeholder="enter your name" class="box">
			<span>Email</span>
			<input type="email" name="email" placeholder="enter your email" class="box">
			<span>PhoneNo</span>
			<input type="number" name="number" placeholder="enter your number" class="box">
			<span>Date Appointment</span>
			<input type="datetime-local" name="date" class="box">
			<span>Submit</span>
			<input type="submit" name="Make appointment" name="submit" class="link-btn">



		</form>		

	</section>





	<section class="footer">
		<div class="box-container container">
			<div class="box">
				<i class="fas fa-phone"></i>
				<h3>Phone number</h3>
				<p>0324354657</p>
				<p>1324567245</p>

			</div>
			<div class="box">
				<i class="fas fa-map-marker-alt"></i>
				<h3>Our address</h3>
				<p>Rwp</p>
				<p>Rwp</p>

			</div>
			<div class="box">
				<i class="fas fa-clock"></i>
				<h3>opening hour</h3>
				<p>03: 243: 54657</p>
		

			</div>
			<div class="box">
				<i class="fas fa-envelop"></i>
				<h3>Email addrress</h3>
				<p>@gmail.com</p>
				<p>@gmail.com</p>

			</div>
		</div>

	</section>



</body>
</html>