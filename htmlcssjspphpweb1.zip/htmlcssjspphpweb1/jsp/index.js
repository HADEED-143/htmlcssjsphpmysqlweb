let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .nav);

 

menu.onClick = () => {

	menu.classList.toggle('fa-times');
	menu.classList.toggle('active');

}
windows.onScroll = () =>{
	menu.classList.remove('fa-times');
	navbar.classList.remove('active');

}
if (window.scrollY > 0) {
	header.classList.add('active');
else{
	header.classList.remove('active');
}
}